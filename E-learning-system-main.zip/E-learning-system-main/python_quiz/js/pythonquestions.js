// creating an array and passing the number, questions, options, and answers
let questions = [
  {
    numb: 1,
    question: "Who developed the python language?",
    answer: "Guido van Rossum",
    options: [
      "Niene Stom",
      "Guido van Rossum",
      "Wick van Rossum",
      "Zim Den"
    ]
  },
  {
    numb: 2,
    question: "Example of mutable data type?",
    answer: "list",
    options: [
      "tuple",
      "list",
      "string",
      "integers"
    ]
  },
  {
    numb: 3,
    question: "what is the extension of python file?",
    answer: ".py",
    options: [
      ".python",
      ".py",
      ".java",
      ".html"
    ]
  },
  {
    numb: 4,
    question: "Which of the following is not a keyword in python language?",
    answer: "val",
    options: [
      "raise",
      "val",
      "try",
      "with"
    ]
  },
  {
    numb: 5,
    question: "In which year was the python language developed?",
    answer: "1989",
    options: [
      "1990",
      "1989",
      "1975",
      "1980"
    ]
  },

];
