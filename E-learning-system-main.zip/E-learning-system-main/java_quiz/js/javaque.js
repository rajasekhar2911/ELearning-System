// creating an array and passing the number, questions, options, and answers
let questions = [
    {
        numb: 1,
        question: "who invented Java Programing?",
        answer: "James Gosling",
        options: [
            "Guido van Rossum",
            "James Gosling",
            "Dennis Ricthie",
            "Rasmus Lerdorf"
        ]
    },
    {
        numb: 2,
        question: "Which Component is used to compile debug and excute the java programs?",
        answer: "JDK",
        options: [
            "JRE",
            "JIT",
            "JDK",
            "JVM"
        ]
    },
    {
        numb: 3,
        question: "Which one of the following is not a java feature?",
        answer: "Use of pointers",
        options: [
            "Object_oriented",
            "Use of pointers",
            "Portable",
            "Dynamic and Extensible"
        ]
    },
    {
        numb: 4,
        question: "Which of these cannot be used for a variable name in java?",
        answer: "keyword",
        options: [
            "identifier and keyword",
            "identifier",
            "keyword",
            "none of the mentioned"
        ]
    },
    {
        numb: 5,
        question: "what is the extension of java code files?",
        answer: ".java",
        options: [
            ".js",
            ".txt",
            ".java",
            ".py"
        ]
    },
];