// creating an array and passing the number, questions, options, and answers
let questions = [
    {
        numb: 1,
        question: "who is father of c language?",
        answer: "Dennis Ricthie",
        options: [
            "Steve jobs",
            "James Goslings",
            "Dennis Ricthie",
            "Rasmus Lerdorf"
        ]
    },
    {
        numb: 2,
        question: "All key words in C are in ?",
        answer: "LowerCase letters",
        options: [
            "Uppercase letters",
            "CamelCase lettes",
            "LowerCase letters",
            "None of the mentioned"
        ]
    },
    {
        numb: 3,
        question: "What is an example of iteration in C?",
        answer: "All of the mentioned",
        options: [
            "For",
            "While",
            "Do_while",
            "All of the mentioned"
        ]
    },
    {
        numb: 4,
        question: "Functions in C language?",
        answer: "Both Internal and External",
        options: [
            "Internal",
            "Extenal",
            "Both Internal and External",
            "External and internal are not valid terms for functions"
        ]
    },
    {
        numb: 5,
        question: "In C language,File is of which data type?",
        answer: "Struct",
        options: [
            "Int",
            "Char*",
            "Struct",
            "None of the mentioned"
        ]
    },
];